
#include <driverlib.h>
#include "myTimers.h"
#include "hal_LCD.h"


void initTimers( uint16_t myPeriod, uint16_t myDutyCycle )
{


    int a;
   a= myDutyCycle ;

   if (a== 4000 )
      {

       displayScrollText("1200 RPM");

   }
      else if (a==3000 )
   {
       displayScrollText("1000 RPM");

       }

      else if (a==2000 )
         {
             displayScrollText("800 RPM");

             }

      else if (a==1000 )
               {
                   displayScrollText("600 RPM");

                }


      else
      {
          displayScrollText("READY TO WASH");
      }


    Timer_A_outputPWMParam param = { 0 };
        param.clockSource = TIMER_A_CLOCKSOURCE_ACLK;
        param.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;
        param.timerPeriod = myPeriod;
        param.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_2;
        param.compareOutputMode = TIMER_A_OUTPUTMODE_RESET_SET;
        param.dutyCycle = myDutyCycle;
    Timer_A_outputPWM( TIMER_A1_BASE, &param );

}




